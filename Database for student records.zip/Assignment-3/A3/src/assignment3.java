public class assignment3{
  public static void main(String[] args){
    SCBST d=new SCBST("input.txt");
    d.read();
  }
}
